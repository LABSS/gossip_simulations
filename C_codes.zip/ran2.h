float ran2(long *idum);
